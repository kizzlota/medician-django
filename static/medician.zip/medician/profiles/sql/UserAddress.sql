INSERT INTO profiles_useraddress (phone, address, city, street, country) VALUES ('John', 'Lennon', 'John', 'Lennon', 'John');

